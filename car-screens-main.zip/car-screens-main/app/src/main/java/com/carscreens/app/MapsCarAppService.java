package com.carscreens.app;

import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import androidx.car.app.CarAppService;
import androidx.car.app.CarContext;
import androidx.car.app.Session;
import androidx.car.app.Screen;
import androidx.car.app.model.Action;
import androidx.car.app.model.ItemList;
import androidx.car.app.model.ListTemplate;
import androidx.car.app.model.Row;
import androidx.car.app.model.Template;

public class MapsCarAppService extends CarAppService {
  @Override public Session onCreateSession() { return new MapsSession(); }
  static class MapsSession extends Session {
    @Override public Screen onCreateScreen(Intent intent) { return new MapsScreen(getCarContext()); }
  }
  static class MapsScreen extends Screen {
    MapsScreen(CarContext context) { super(context); }
    @Override public Template onGetTemplate() {
      ItemList.Builder list = new ItemList.Builder();
      SharedPreferences prefs = getCarContext().getSharedPreferences("ameer_maps", 0);
      int count = 0;
      try {
        JSONArray apps = new JSONArray(prefs.getString("apps", "[]"));
        for (int i=0; i<apps.length(); i++) {
          JSONObject app = apps.optJSONObject(i); if (app == null) continue;
          final String name = app.optString("n", "خرائط");
          final String pkg = app.optString("p", ""); if (pkg.isEmpty()) continue;
          list.addItem(new Row.Builder().setTitle(name).addText("اضغط لفتح تطبيق الملاحة على شاشة السيارة")
            .setOnClickListener(() -> openMap()).build()); count++;
        }
      } catch (Exception ignored) {}
      if (count == 0) list.addItem(new Row.Builder().setTitle("ماكو تطبيقات خرائط مضافة")
        .addText("أضف تطبيق الخرائط من قسم الخرائط في أمير على الهاتف").build());
      return new ListTemplate.Builder().setSingleList(list.build()).setTitle("خرائط أمير")
        .setHeaderAction(Action.APP_ICON).build();
    }
    private void openMap() {
      // Android Auto only supports ACTION_NAVIGATE here; it routes to the
      // navigation app selected by the car/phone system. Explicit package
      // targeting is rejected by CarContext.startCarApp.
      Intent nav = new Intent(CarContext.ACTION_NAVIGATE, Uri.parse("geo:0,0"));
      getCarContext().startCarApp(nav);
    }
  }
}
