package com.carscreens.app;

import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import androidx.car.app.CarAppService;
import androidx.car.app.CarContext;
import androidx.car.app.Session;
import androidx.car.app.Screen;
import androidx.car.app.model.Action;
import androidx.car.app.model.ItemList;
import androidx.car.app.model.ListTemplate;
import androidx.car.app.model.Row;
import androidx.car.app.model.Template;

public class MapsCarAppService extends CarAppService {
  @Override public Session onCreateSession() { return new MapsSession(); }
  static class MapsSession extends Session {
    @Override public Screen onCreateScreen(Intent intent) { return new MapsScreen(getCarContext()); }
  }
  static class MapsScreen extends Screen {
    MapsScreen(CarContext context) { super(context); }
    @Override public Template onGetTemplate() {
      ItemList.Builder list = new ItemList.Builder();
      SharedPreferences prefs = getCarContext().getSharedPreferences("ameer_maps", 0);
      int count = 0;
      try {
        JSONArray apps = new JSONArray(prefs.getString("apps", "[]"));
        for (int i=0; i<apps.length(); i++) {
          JSONObject app = apps.optJSONObject(i); if (app == null) continue;
          final String name = app.optString("n", "خرائط");
          final String pkg = app.optString("p", ""); if (pkg.isEmpty()) continue;
          list.addItem(new Row.Builder().setTitle(name).addText("اضغط لفتح التطبيق المختار على الهاتف")
            .setOnClickListener(() -> openSelectedApp(pkg)).build()); count++;
        }
      } catch (Exception ignored) {}
      if (count == 0) list.addItem(new Row.Builder().setTitle("ماكو تطبيقات خرائط مضافة")
        .addText("أضف تطبيق الخرائط من قسم الخرائط في أمير على الهاتف").build());
      return new ListTemplate.Builder().setSingleList(list.build()).setTitle("خرائط أمير")
        .setHeaderAction(Action.APP_ICON).build();
    }
    private void openSelectedApp(String packageName) {
      // A Car App cannot force another app's UI onto the Android Auto display.
      // Launch the selected phone app when Android permits it; otherwise fall
      // back to the system navigation handler.
      try {
        Intent launch = getCarContext().getPackageManager()
            .getLaunchIntentForPackage(packageName);
        if (launch != null) {
          launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
          getCarContext().startActivity(launch);
          return;
        }
      } catch (Exception ignored) {}

      Intent nav = new Intent(CarContext.ACTION_NAVIGATE, Uri.parse("geo:0,0"));
      getCarContext().startCarApp(nav);
    }
  }
}
