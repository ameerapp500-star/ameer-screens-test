package com.carscreens.app;
import android.content.ContentUris;
import android.database.Cursor;
import android.media.AudioAttributes;
import android.media.MediaDescription;
import android.media.MediaPlayer;
import android.media.browse.MediaBrowser;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.service.media.MediaBrowserService;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class AutoService extends MediaBrowserService {
  MediaSession ses; MediaPlayer mp;
  static final String API = "https://de1.api.radio-browser.info/json/";

  @Override public void onCreate() {
    super.onCreate();
    ses = new MediaSession(this, "CarScreens");
    ses.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
    ses.setCallback(new MediaSession.Callback() {
      @Override public void onPlayFromMediaId(String id, Bundle extras) { play(id); }
      @Override public void onPlay() { if (mp != null) { mp.start(); st(PlaybackState.STATE_PLAYING); } }
      @Override public void onPause() { if (mp != null && mp.isPlaying()) { mp.pause(); st(PlaybackState.STATE_PAUSED); } }
      @Override public void onStop() { rel(); st(PlaybackState.STATE_STOPPED); }
    });
    setSessionToken(ses.getSessionToken());
    ses.setActive(true);
    st(PlaybackState.STATE_NONE);
  }

  void st(int s) {
    ses.setPlaybackState(new PlaybackState.Builder()
      .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_STOP | PlaybackState.ACTION_PLAY_FROM_MEDIA_ID)
      .setState(s, 0, 1f).build());
  }
  void rel() { if (mp != null) { try { mp.release(); } catch (Exception e) {} mp = null; } }

  void play(String id) {
    rel();
    try {
      mp = new MediaPlayer();
      mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
      mp.setDataSource(this, Uri.parse(id));
      mp.setOnPreparedListener(p -> { p.start(); st(PlaybackState.STATE_PLAYING); });
      mp.setOnErrorListener((p, w, e) -> { st(PlaybackState.STATE_ERROR); return true; });
      st(PlaybackState.STATE_BUFFERING);
      mp.prepareAsync();
    } catch (Exception e) { st(PlaybackState.STATE_ERROR); }
  }

  @Override public BrowserRoot onGetRoot(String pkg, int uid, Bundle hints) { return new BrowserRoot("root", null); }

  MediaBrowser.MediaItem item(String id, String title, int flag) {
    return new MediaBrowser.MediaItem(new MediaDescription.Builder().setMediaId(id).setTitle(title).build(), flag);
  }

  String get(String path) throws Exception {
    HttpURLConnection c = (HttpURLConnection) new URL(API + path).openConnection();
    c.setRequestProperty("User-Agent", "CarScreens/1.0");
    c.setConnectTimeout(10000); c.setReadTimeout(15000);
    BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
    StringBuilder sb = new StringBuilder(); String l;
    while ((l = r.readLine()) != null) sb.append(l);
    r.close();
    return sb.toString();
  }

  @Override public void onLoadChildren(final String pid, final Result<List<MediaBrowser.MediaItem>> res) {
    res.detach();
    new Thread(new Runnable() { public void run() {
      List<MediaBrowser.MediaItem> out = new ArrayList<MediaBrowser.MediaItem>();
      try {
        int B = MediaBrowser.MediaItem.FLAG_BROWSABLE, P = MediaBrowser.MediaItem.FLAG_PLAYABLE;
        if (pid.equals("root")) {
          out.add(item("radio", "الراديو", B));
          out.add(item("music", "الموسيقى", B));
        } else if (pid.equals("radio")) {
          JSONArray a = new JSONArray(get("countries?hidebroken=true"));
          List<JSONObject> l = new ArrayList<JSONObject>();
          for (int i = 0; i < a.length(); i++) l.add(a.getJSONObject(i));
          Collections.sort(l, new Comparator<JSONObject>() { public int compare(JSONObject x, JSONObject y) { return y.optInt("stationcount") - x.optInt("stationcount"); }});
          for (int i = 0; i < l.size() && i < 40; i++) {
            JSONObject o = l.get(i);
            out.add(item("c:" + o.getString("iso_3166_1"), o.getString("name") + " (" + o.optInt("stationcount") + ")", B));
          }
        } else if (pid.startsWith("c:")) {
          JSONArray a = new JSONArray(get("stations/search?countrycode=" + pid.substring(2) + "&hidebroken=true&order=votes&reverse=true&limit=60"));
          for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            String u = o.optString("url_resolved");
            if (u.length() > 0) out.add(item(u, o.optString("name").trim(), P));
          }
        } else if (pid.equals("music")) {
          Uri base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
          Cursor c = getContentResolver().query(base, new String[]{MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE}, null, null, MediaStore.Audio.Media.DATE_ADDED + " DESC");
          if (c != null) {
            int n = 0;
            while (c.moveToNext() && n++ < 200) out.add(item(ContentUris.withAppendedId(base, c.getLong(0)).toString(), c.getString(1), P));
            c.close();
          }
        }
      } catch (Exception e) {}
      res.sendResult(out);
    }}).start();
  }

  @Override public void onDestroy() { rel(); ses.release(); super.onDestroy(); }
}
